import { createClient } from "@/lib/supabase/server";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DailyDashboardSummary } from "@/components/dashboard/DailyDashboardSummary";
import { TodaysTasks } from "@/components/dashboard/TodaysTasks";
import { ProjectsSummary } from "@/components/dashboard/ProjectsSummary";
import { ClientsSummary } from "@/components/dashboard/ClientsSummary";
import { EarningsSummary } from "@/components/dashboard/EarningsSummary";
import { AIAssistantPanel } from "@/components/dashboard/AIAssistantPanel";
import { ProfileSection } from "@/components/dashboard/ProfileSection";

// Server component — fetches everything in parallel, real data only.
// No mock/fake data: every section renders its own empty state when a
// table has no rows for this user yet.
export default async function DashboardPage() {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const today = new Date().toISOString().slice(0, 10);

  const [
    { data: profile },
    { data: tasks },
    { data: projects },
    { data: clients },
    { data: earnings },
    { data: dashboard },
  ] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", user!.id).single(),
    supabase
      .from("tasks")
      .select("*")
      .eq("user_id", user!.id)
      .neq("status", "completed")
      .order("deadline", { ascending: true })
      .limit(10),
    supabase.from("projects").select("*").eq("user_id", user!.id).order("created_at", { ascending: false }),
    supabase.from("clients").select("*").eq("user_id", user!.id).order("created_at", { ascending: false }),
    supabase
      .from("earnings_log")
      .select("*")
      .eq("user_id", user!.id)
      .order("earned_date", { ascending: false })
      .limit(20),
    supabase.from("daily_dashboards").select("*").eq("user_id", user!.id).eq("date", today).maybeSingle(),
  ]);

  return (
    <>
      <DashboardHeader fullName={profile?.full_name ?? null} />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <DailyDashboardSummary dashboard={dashboard ?? null} />
        <AIAssistantPanel />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <TodaysTasks tasks={tasks ?? []} />
        <ProjectsSummary projects={projects ?? []} />
        <ClientsSummary clients={clients ?? []} />
        <EarningsSummary entries={earnings ?? []} />
        <ProfileSection profile={profile ?? null} email={user?.email} />
      </div>
    </>
  );
}
