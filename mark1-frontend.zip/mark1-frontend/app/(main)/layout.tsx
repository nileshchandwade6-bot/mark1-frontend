import { Sidebar } from "@/components/nav/Sidebar";
import { MobileNav } from "@/components/nav/MobileNav";

// Shared shell for every protected page. middleware.ts already guarantees
// a logged-in user reaches this layout — no auth check needed here.
export default function MainLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-paper">
      <Sidebar />
      <div className="flex-1 min-w-0">
        <main className="px-4 sm:px-6 py-6 pb-24 md:pb-6 max-w-5xl mx-auto">{children}</main>
      </div>
      <MobileNav />
    </div>
  );
}
