"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({ email, password });

    setLoading(false);
    if (error) {
      setError(error.message);
      return;
    }
    router.refresh();
    router.push("/dashboard");
  }

  return (
    <main className="min-h-screen flex flex-col justify-center px-6 py-12 bg-ink">
      <div className="mx-auto w-full max-w-sm">
        <div className="mb-10 text-center">
          <p className="font-mono text-xs tracking-[0.2em] text-brass-light uppercase mb-2">
            Vyroniq AI
          </p>
          <h1 className="font-display text-3xl font-semibold text-paper">MARK-1</h1>
          <p className="mt-1 text-sm text-slate-400">Sign in to your command deck</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-paper-card rounded-card p-6 shadow-xl shadow-black/20"
        >
          <label className="block mb-4">
            <span className="text-xs font-medium text-slate-600">Email</span>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2.5 text-slate-900 focus:border-signal focus:ring-1 focus:ring-signal outline-none"
              placeholder="you@example.com"
            />
          </label>

          <label className="block mb-6">
            <span className="text-xs font-medium text-slate-600">Password</span>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 w-full rounded-lg border border-slate-200 px-3 py-2.5 text-slate-900 focus:border-signal focus:ring-1 focus:ring-signal outline-none"
              placeholder="••••••••"
            />
          </label>

          {error && (
            <p className="mb-4 text-sm text-danger" role="alert">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-lg bg-ink py-2.5 text-sm font-semibold text-paper transition hover:bg-ink-light disabled:opacity-60"
          >
            {loading ? "Signing in…" : "Sign in"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-slate-400">
          New here?{" "}
          <Link href="/signup" className="font-medium text-brass-light hover:underline">
            Create an account
          </Link>
        </p>
      </div>
    </main>
  );
}
